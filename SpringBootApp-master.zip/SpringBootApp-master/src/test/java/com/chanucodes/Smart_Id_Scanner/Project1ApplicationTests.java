package com.chanucodes.Smart_Id_Scanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
